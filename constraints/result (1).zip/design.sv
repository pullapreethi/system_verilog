// Code your design here
/*foreach(p1.a[i])
   begin
     $display("a[%d]=%d",i,p1.a); 
   end*/
/* 
# array a='{}
# a[0]=1 2 3 4 5
# a[1]=1 2 3 4 5
# a[2]=1 2 3 4 5
# a[3]=1 2 3 4 5
# a[4]=1 2 3 4 5*/
//    a[i]==!(i%2==0);}
